import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const webDir = path.resolve(here, '../../Resources/Web');
const rpcSource = fs.readFileSync(path.join(webDir, 'ios-rpc.js'), 'utf8');
const bridgeSource = fs.readFileSync(path.join(webDir, 'ios-wb-bridge.js'), 'utf8');
const deviceId = 'A1B2C3D4-1111-2222-3333-444455556666';
const service16 = '0000ffe0-0000-1000-8000-00805f9b34fb';
const characteristic16 = '0000ffe1-0000-1000-8000-00805f9b34fb';

function createHarness() {
  const messages = [];
  const pageListeners = {};
  const window = {
    isSecureContext: true,
    addEventListener(type, callback) { (pageListeners[type] ||= []).push(callback); },
    webkit: {
      messageHandlers: {
        bms: {
          postMessage(message) { messages.push(message); }
        }
      }
    }
  };
  const navigator = {};
  const context = vm.createContext({
    window,
    navigator,
    console,
    Promise,
    ArrayBuffer,
    DataView,
    Uint8Array,
    Array,
    Object,
    String,
    Number,
    Boolean,
    JSON,
    Error,
    Date,
    setTimeout,
    clearTimeout,
    btoa(value) { return Buffer.from(value, 'binary').toString('base64'); },
    atob(value) { return Buffer.from(value, 'base64').toString('binary'); }
  });
  new vm.Script(rpcSource).runInContext(context);
  new vm.Script(bridgeSource).runInContext(context);

  function take(method) {
    const index = messages.findIndex(message => message.method === method);
    assert.notEqual(index, -1, `Expected native call: ${method}`);
    return messages.splice(index, 1)[0];
  }
  function ok(request, value = null) {
    assert.equal(window.__bmsNativeCallback({
      type: 'response', id: request.id, ok: true, value
    }), true);
  }
  function fail(request, name, message) {
    window.__bmsNativeCallback({ type: 'response', id: request.id, ok: false, error: { name, message } });
  }
  function event(name, value) {
    assert.equal(window.__bmsNativeCallback({ type: 'event', name, value }), true);
  }

  ok(take('notifStatus'), 'granted');
  return { window, navigator, messages, pageListeners, take, ok, fail, event };
}

async function connectedCharacteristic(harness) {
  const devicesPromise = harness.navigator.bluetooth.getDevices();
  harness.ok(harness.take('getDevices'), [{ id: deviceId, name: 'ANT@TEST' }]);
  const [device] = await devicesPromise;

  const servicesPromise = device.gatt.getPrimaryServices();
  harness.ok(harness.take('getServices'), ['FFE0']);
  const [service] = await servicesPromise;

  const characteristicsPromise = service.getCharacteristics();
  harness.ok(harness.take('getCharacteristics'), [{
    uuid: 'FFE1', read: true, write: true, writeWithoutResponse: true, notify: true
  }]);
  const [characteristic] = await characteristicsPromise;
  return { device, service, characteristic };
}

test('RPC resolves once, preserves native errors, and rejects on timeout', async () => {
  const harness = createHarness();
  const requestPromise = harness.window.BMSRPC.call('getDevices');
  const request = harness.take('getDevices');
  harness.ok(request, [{ id: deviceId, name: 'ANT@TEST' }]);
  assert.deepEqual(await requestPromise, [{ id: deviceId, name: 'ANT@TEST' }]);
  assert.equal(harness.window.__bmsNativeCallback({
    type: 'response', id: request.id, ok: true, value: []
  }), false, 'duplicate response must be ignored');

  const missingPromise = harness.window.BMSRPC.call('read');
  harness.fail(harness.take('read'), 'NotFoundError', 'missing');
  await assert.rejects(missingPromise, error => error.name === 'NotFoundError' && error.message === 'missing');

  const timeoutPromise = harness.window.BMSRPC.call('read', {}, 5);
  harness.take('read');
  await assert.rejects(timeoutPromise, error => error.name === 'NetworkError' && /超时/.test(error.message));
});

test('pagehide rejects outstanding RPC requests', async () => {
  const harness = createHarness();
  const pending = harness.window.BMSRPC.call('getDevices');
  harness.take('getDevices');
  for (const callback of harness.pageListeners.pagehide || []) callback();
  await assert.rejects(pending, error => error.name === 'AbortError');
});

test('UUIDs are canonicalized across service, characteristic, and notification paths', async () => {
  const harness = createHarness();
  const { characteristic } = await connectedCharacteristic(harness);
  assert.equal(characteristic.service.uuid, service16);
  assert.equal(characteristic.uuid, characteristic16);

  const subscribePromise = characteristic.startNotifications();
  const subscribe = harness.take('setNotify');
  assert.equal(subscribe.params.serviceUuid, service16);
  assert.equal(subscribe.params.characteristicUuid, characteristic16);
  assert.equal(subscribe.params.enabled, true);
  harness.ok(subscribe);
  assert.equal(await subscribePromise, characteristic);

  let received;
  characteristic.addEventListener('characteristicvaluechanged', event => { received = event.target.value; });
  harness.event('notification', {
    deviceId,
    serviceUuid: service16,
    characteristicUuid: 'FFE1',
    data: Buffer.from([0x7e, 0xa1, 0xff]).toString('base64')
  });
  assert.ok(received instanceof DataView);
  assert.deepEqual(Array.from(new Uint8Array(received.buffer)), [0x7e, 0xa1, 0xff]);
});

test('read and both write modes preserve binary payloads', async () => {
  const harness = createHarness();
  const { characteristic } = await connectedCharacteristic(harness);

  const readPromise = characteristic.readValue();
  const read = harness.take('read');
  harness.ok(read, Buffer.from([1, 2, 3]).toString('base64'));
  const value = await readPromise;
  assert.deepEqual(Array.from(new Uint8Array(value.buffer)), [1, 2, 3]);

  const bytes = new Uint8Array([9, 0x7e, 0xa1, 0, 8]).subarray(1, 4);
  const withoutResponsePromise = characteristic.writeValueWithoutResponse(bytes);
  const withoutResponse = harness.take('write');
  assert.equal(withoutResponse.params.withResponse, false);
  assert.equal(withoutResponse.params.data, Buffer.from([0x7e, 0xa1, 0]).toString('base64'));
  harness.ok(withoutResponse);
  await withoutResponsePromise;

  const withResponsePromise = characteristic.writeValueWithResponse(new Uint8Array([0x7e, 0xa2]));
  const withResponse = harness.take('write');
  assert.equal(withResponse.params.withResponse, true);
  harness.ok(withResponse);
  await withResponsePromise;
});

test('GATT connect resolves only after native discovery completes and disconnect emits once', async () => {
  const harness = createHarness();
  const devicesPromise = harness.navigator.bluetooth.getDevices();
  harness.ok(harness.take('getDevices'), [{ id: deviceId, name: 'ANT@TEST' }]);
  const [device] = await devicesPromise;

  let connected = false;
  const connectPromise = device.gatt.connect().then(server => { connected = true; return server; });
  harness.ok(harness.take('connect'));
  await Promise.resolve();
  assert.equal(connected, false);
  harness.event('connected', { id: deviceId });
  assert.equal(await connectPromise, device.gatt);
  assert.equal(device.gatt.connected, true);

  let disconnects = 0;
  device.addEventListener('gattserverdisconnected', () => { disconnects += 1; });
  harness.event('disconnected', { id: deviceId, message: '断电' });
  assert.equal(disconnects, 1);
  assert.equal(device.gatt.connected, false);
});

test('device selection resolves and cancellation rejects the original request', async () => {
  const harness = createHarness();
  let optionsSeen;
  harness.window.__wbOpenCard = options => { optionsSeen = options; return true; };

  const selection = harness.navigator.bluetooth.requestDevice({ acceptAllDevices: true });
  assert.equal(optionsSeen.acceptAllDevices, true);
  harness.window.__wbPicked(deviceId, 'ANT@TEST');
  const device = await selection;
  assert.equal(device.id, deviceId);
  assert.equal(device.name, 'ANT@TEST');

  const cancelled = harness.navigator.bluetooth.requestDevice({});
  harness.window.__wbCancelReq();
  await assert.rejects(cancelled, error => error.name === 'NotFoundError' && error.message === 'cancel');
  assert.equal(harness.messages.length, 0);
});

test('scan events reach the existing connection card callback', async () => {
  const harness = createHarness();
  const hits = [];
  harness.window.__bleInlineScanHit = (...args) => hits.push(args);
  const scanPromise = harness.window.BMSApp.wbScan();
  harness.ok(harness.take('scanStart'));
  await scanPromise;
  harness.event('scanResult', { id: deviceId, name: 'ANT@TEST', rssi: -55, likely: true });
  assert.deepEqual(hits, [[deviceId, 'ANT@TEST', -55, true]]);
});

test('same characteristic UUID in two services keeps independent notification targets', async () => {
  const harness = createHarness();
  const devicesPromise = harness.navigator.bluetooth.getDevices();
  harness.ok(harness.take('getDevices'), [{ id: deviceId, name: 'ANT@TEST' }]);
  const [device] = await devicesPromise;

  const servicesPromise = device.gatt.getPrimaryServices();
  harness.ok(harness.take('getServices'), ['FFE0', 'FF00']);
  const services = await servicesPromise;
  const characteristics = [];
  for (const service of services) {
    const promise = service.getCharacteristics();
    harness.ok(harness.take('getCharacteristics'), [{ uuid: 'FFE1', notify: true }]);
    characteristics.push((await promise)[0]);
  }

  const hits = [0, 0];
  characteristics.forEach((characteristic, index) => {
    characteristic.addEventListener('characteristicvaluechanged', () => { hits[index] += 1; });
  });
  harness.event('notification', {
    deviceId,
    serviceUuid: service16,
    characteristicUuid: characteristic16,
    data: Buffer.from([1]).toString('base64')
  });
  assert.deepEqual(hits, [1, 0]);
});

test('notification permission and native notification calls use RPC', async () => {
  const harness = createHarness();
  await Promise.resolve();
  assert.equal(harness.window.Notification.permission, 'granted');

  let callbackPermission;
  const permissionPromise = harness.window.Notification.requestPermission(value => { callbackPermission = value; });
  harness.ok(harness.take('notifRequest'), 'granted');
  assert.equal(await permissionPromise, 'granted');
  assert.equal(callbackPermission, 'granted');

  const notification = new harness.window.Notification('报警', { body: '电压异常' });
  assert.equal(notification.title, '报警');
  const request = harness.take('notify');
  assert.equal(request.params.title, '报警');
  assert.equal(request.params.body, '电压异常');
  harness.ok(request);
});

test('bundled HTML inline scripts remain syntactically valid', () => {
  const html = fs.readFileSync(path.join(webDir, 'bms.html'), 'utf8');
  const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)];
  assert.ok(scripts.length >= 10, 'expected the original inline application scripts');
  scripts.forEach((match, index) => {
    assert.doesNotThrow(() => new vm.Script(match[1]), `inline script ${index + 1}`);
  });
});
