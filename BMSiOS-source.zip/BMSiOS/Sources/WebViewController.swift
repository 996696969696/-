import UIKit
import WebKit

final class ScriptMessageHandlerProxy: NSObject, WKScriptMessageHandler {
    private weak var delegate: WKScriptMessageHandler?

    init(delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}

final class WebViewController: UIViewController, WKNavigationDelegate {
    private let bridge = NativeBridge()
    private var webView: WKWebView!
    private var loadingLocalPage = false
    private let remoteURL = URL(string: "https://sbljhl.cc.cd")!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        let contentController = WKUserContentController()
        contentController.add(ScriptMessageHandlerProxy(delegate: bridge), name: "bms")
        addUserScript(named: "ios-rpc", to: contentController)
        addUserScript(named: "ios-wb-bridge", to: contentController)
        addUserScript(named: "conn-card", to: contentController)

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        configuration.allowsInlineMediaPlayback = true

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        bridge.attach(to: webView)
        loadRemote()
    }

    private func addUserScript(named name: String, to controller: WKUserContentController) {
        guard let url = Self.webResource(named: name, extension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else {
            assertionFailure("Missing web resource: \(name).js")
            return
        }
        controller.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
    }

    private static func webResource(named name: String, extension ext: String) -> URL? {
        if let url = Bundle.main.url(forResource: name, withExtension: ext, subdirectory: "Web") {
            return url
        }
        return Bundle.main.url(forResource: name, withExtension: ext)
    }

    private func loadRemote() {
        loadingLocalPage = false
        webView.load(URLRequest(url: remoteURL, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 30))
    }

    private func loadLocalPage() {
        guard let url = Self.webResource(named: "bms", extension: "html") else {
            assertionFailure("Missing bundled bms.html")
            return
        }
        loadingLocalPage = true
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    private func offerLocalPage() {
        guard presentedViewController == nil, !loadingLocalPage else { return }
        let alert = UIAlertController(title: "远程页面加载失败", message: "可以重试，或使用内置页面进行蓝牙直连。", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "重试", style: .default) { [weak self] _ in self?.loadRemote() })
        alert.addAction(UIAlertAction(title: "打开内置页面", style: .default) { [weak self] _ in self?.loadLocalPage() })
        present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { offerLocalPage() }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { offerLocalPage() }
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard navigationAction.targetFrame?.isMainFrame != false,
              let url = navigationAction.request.url,
              let scheme = url.scheme?.lowercased(),
              scheme == "https" || scheme == "http" else {
            decisionHandler(.allow)
            return
        }
        if scheme == "https", url.host?.lowercased() == remoteURL.host?.lowercased() {
            decisionHandler(.allow)
        } else {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
        }
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "bms")
    }
}
