import CoreBluetooth
import Foundation

final class BLEManager: NSObject {
    typealias Completion = (Result<Any, Error>) -> Void

    var eventHandler: ((String, [String: Any]) -> Void)?

    private let queue = DispatchQueue(label: "cc.cd.sbljhl.bms.ble")
    private lazy var central = CBCentralManager(
        delegate: self,
        queue: queue,
        options: [CBCentralManagerOptionShowPowerAlertKey: true]
    )
    private let defaults = UserDefaults.standard
    private let savedIDsKey = "BMSSavedPeripheralIDs"
    private let namesKey = "BMSPeripheralNames"

    private var discovered: [UUID: CBPeripheral] = [:]
    private var peripheral: CBPeripheral?
    private var savedIDs = Set<String>()
    private var savedNames: [String: String] = [:]
    private var powerWaiters: [(Result<Void, Error>) -> Void] = []

    private var ready = false
    private var discovering = false
    private var pendingServices = Set<ObjectIdentifier>()
    private var connectionTimeout: DispatchWorkItem?
    private var discoveryTimeout: DispatchWorkItem?
    private var scanTimeout: DispatchWorkItem?

    private struct PendingOperation {
        let completion: Completion
        let timeout: DispatchWorkItem
    }
    private var reads: [ObjectIdentifier: PendingOperation] = [:]
    private var notifications: [ObjectIdentifier: PendingOperation] = [:]

    private struct WriteOperation {
        let id = UUID()
        let characteristic: CBCharacteristic
        let data: Data
        let type: CBCharacteristicWriteType
        let completion: Completion
    }
    private var writeQueue: [WriteOperation] = []
    private var activeWrite: WriteOperation?
    private var writeTimeout: DispatchWorkItem?

    override init() {
        super.init()
        savedIDs = Set(defaults.stringArray(forKey: savedIDsKey) ?? [])
        savedNames = defaults.dictionary(forKey: namesKey) as? [String: String] ?? [:]
    }

    func scanStart(completion: @escaping Completion) {
        queue.async {
            self.withPower { result in
                if let error = result.error { completion(.failure(error)); return }
                self.discovered.removeAll()
                self.scanTimeout?.cancel()
                let timeout = DispatchWorkItem { [weak self] in
                    self?.central.stopScan()
                    self?.scanTimeout = nil
                }
                self.scanTimeout = timeout
                self.queue.asyncAfter(deadline: .now() + 20, execute: timeout)
                self.central.scanForPeripherals(
                    withServices: nil,
                    options: [CBCentralManagerScanOptionAllowDuplicatesKey: true]
                )
                completion(.success(NSNull()))
            }
        }
    }

    func scanStop(completion: @escaping Completion) {
        queue.async {
            self.scanTimeout?.cancel()
            self.scanTimeout = nil
            self.central.stopScan()
            completion(.success(NSNull()))
        }
    }

    func getDevices(completion: @escaping Completion) {
        queue.async {
            self.withPower { result in
                if let error = result.error { completion(.failure(error)); return }
                let identifiers = self.savedIDs.compactMap(UUID.init(uuidString:))
                var peripherals = self.central.retrievePeripherals(withIdentifiers: identifiers)
                if let active = self.peripheral, !peripherals.contains(where: { $0.identifier == active.identifier }) {
                    peripherals.append(active)
                }
                let devices = peripherals.map { item -> [String: Any] in
                    let id = item.identifier.uuidString
                    self.discovered[item.identifier] = item
                    return ["id": id, "name": self.savedNames[id] ?? item.name ?? id]
                }
                completion(.success(devices))
            }
        }
    }

    func connect(deviceId: String, completion: @escaping Completion) {
        queue.async {
            self.withPower { result in
                if let error = result.error { completion(.failure(error)); return }
                guard let uuid = UUID(uuidString: deviceId) else {
                    completion(.failure(BridgeError.invalidRequest("设备标识无效")))
                    return
                }
                guard let item = self.discovered[uuid] ?? self.central.retrievePeripherals(withIdentifiers: [uuid]).first else {
                    completion(.failure(BridgeError.notFound("找不到该设备，请重新扫描")))
                    return
                }
                if let active = self.peripheral, active.identifier != item.identifier,
                   active.state == .connected || active.state == .connecting {
                    completion(.failure(BridgeError.invalidRequest("已有另一台保护板正在连接")))
                    return
                }

                self.peripheral = item
                item.delegate = self
                self.remember(item)
                self.ready = false
                if item.state == .connected {
                    completion(.success(NSNull()))
                    self.startDiscovery(on: item)
                } else if item.state == .connecting {
                    completion(.success(NSNull()))
                    self.startConnectionTimeout(for: item)
                } else {
                    self.startConnectionTimeout(for: item)
                    self.central.connect(item, options: nil)
                    completion(.success(NSNull()))
                }
            }
        }
    }

    func disconnect(deviceId: String?, completion: @escaping Completion) {
        queue.async {
            guard let item = self.peripheral else {
                if let deviceId = deviceId { self.emitDisconnected(id: deviceId, message: "已断开") }
                completion(.success(NSNull()))
                return
            }
            if let deviceId = deviceId, item.identifier.uuidString != deviceId {
                completion(.failure(BridgeError.notConnected("该设备不是当前连接")))
                return
            }
            if item.state == .disconnected {
                self.failPendingOperations(BridgeError.notConnected("连接已断开"))
                self.emitDisconnected(id: item.identifier.uuidString, message: "已断开")
            } else {
                self.central.cancelPeripheralConnection(item)
            }
            completion(.success(NSNull()))
        }
    }

    func getServices(deviceId: String, completion: @escaping Completion) {
        queue.async {
            do {
                let item = try self.readyPeripheral(deviceId: deviceId)
                let services = (item.services ?? []).compactMap { Self.canonicalUUID($0.uuid.uuidString) }
                completion(.success(services))
            } catch {
                completion(.failure(error))
            }
        }
    }

    func getCharacteristics(deviceId: String, serviceId: String, completion: @escaping Completion) {
        queue.async {
            do {
                let item = try self.readyPeripheral(deviceId: deviceId)
                guard let wantedService = Self.canonicalUUID(serviceId) else {
                    throw BridgeError.invalidRequest("服务 UUID 无效")
                }
                guard let service = (item.services ?? []).first(where: {
                    Self.canonicalUUID($0.uuid.uuidString) == wantedService
                }) else {
                    throw BridgeError.notFound("设备上没有该服务")
                }
                let descriptors = (service.characteristics ?? []).map { characteristic -> [String: Any] in
                    let properties = characteristic.properties
                    return [
                        "uuid": Self.canonicalUUID(characteristic.uuid.uuidString) ?? characteristic.uuid.uuidString.lowercased(),
                        "read": properties.contains(.read),
                        "write": properties.contains(.write),
                        "writeWithoutResponse": properties.contains(.writeWithoutResponse),
                        "notify": properties.contains(.notify),
                        "indicate": properties.contains(.indicate),
                        "broadcast": properties.contains(.broadcast),
                        "authenticatedSignedWrites": properties.contains(.authenticatedSignedWrites),
                        "reliableWrite": properties.contains(.reliableWrite),
                        "writableAuxiliaries": properties.contains(.writableAuxiliaries)
                    ]
                }
                completion(.success(descriptors))
            } catch {
                completion(.failure(error))
            }
        }
    }

    func read(
        deviceId: String, serviceId: String, characteristicId: String, completion: @escaping Completion
    ) {
        queue.async {
            do {
                let item = try self.readyPeripheral(deviceId: deviceId)
                let characteristic = try self.findCharacteristic(item, serviceId: serviceId, characteristicId: characteristicId)
                let key = ObjectIdentifier(characteristic)
                guard self.reads[key] == nil else {
                    throw BridgeError.invalidRequest("该特征正在读取")
                }
                let timeout = DispatchWorkItem { [weak self] in
                    guard let self = self, let operation = self.reads.removeValue(forKey: key) else { return }
                    operation.completion(.failure(BridgeError.timeout("读取特征超时")))
                }
                self.reads[key] = PendingOperation(completion: completion, timeout: timeout)
                self.queue.asyncAfter(deadline: .now() + 15, execute: timeout)
                item.readValue(for: characteristic)
            } catch {
                completion(.failure(error))
            }
        }
    }

    func write(
        deviceId: String,
        serviceId: String,
        characteristicId: String,
        data: Data,
        withResponse: Bool,
        completion: @escaping Completion
    ) {
        queue.async {
            do {
                let item = try self.readyPeripheral(deviceId: deviceId)
                let characteristic = try self.findCharacteristic(item, serviceId: serviceId, characteristicId: characteristicId)
                let supportsResponse = characteristic.properties.contains(.write)
                let supportsNoResponse = characteristic.properties.contains(.writeWithoutResponse)
                if withResponse && !supportsResponse && !supportsNoResponse {
                    throw BridgeError.failed("该特征不支持写入")
                }
                if !withResponse && !supportsNoResponse {
                    if supportsResponse {
                        throw BridgeError.failed("该特征只支持有响应写入")
                    }
                    throw BridgeError.failed("该特征不支持写入")
                }
                let type: CBCharacteristicWriteType = withResponse && supportsResponse ? .withResponse : .withoutResponse
                self.writeQueue.append(WriteOperation(
                    characteristic: characteristic, data: data, type: type, completion: completion
                ))
                self.processWrites()
            } catch {
                completion(.failure(error))
            }
        }
    }

    func setNotify(
        deviceId: String,
        serviceId: String,
        characteristicId: String,
        enabled: Bool,
        completion: @escaping Completion
    ) {
        queue.async {
            do {
                let item = try self.readyPeripheral(deviceId: deviceId)
                let characteristic = try self.findCharacteristic(item, serviceId: serviceId, characteristicId: characteristicId)
                if characteristic.isNotifying == enabled {
                    completion(.success(NSNull()))
                    return
                }
                let key = ObjectIdentifier(characteristic)
                guard self.notifications[key] == nil else {
                    throw BridgeError.invalidRequest("该特征正在更改订阅状态")
                }
                let timeout = DispatchWorkItem { [weak self] in
                    guard let self = self, let operation = self.notifications.removeValue(forKey: key) else { return }
                    operation.completion(.failure(BridgeError.timeout("更改通知订阅超时")))
                }
                self.notifications[key] = PendingOperation(completion: completion, timeout: timeout)
                self.queue.asyncAfter(deadline: .now() + 15, execute: timeout)
                item.setNotifyValue(enabled, for: characteristic)
            } catch {
                completion(.failure(error))
            }
        }
    }

    private func withPower(completion: @escaping (Result<Void, Error>) -> Void) {
        switch central.state {
        case .poweredOn:
            completion(.success(()))
        case .unknown, .resetting:
            powerWaiters.append(completion)
        case .poweredOff:
            completion(.failure(BridgeError.unavailable("手机蓝牙已关闭")))
        case .unauthorized:
            completion(.failure(BridgeError.unauthorized("请在系统设置中允许使用蓝牙")))
        case .unsupported:
            completion(.failure(BridgeError.unavailable("此设备不支持低功耗蓝牙")))
        @unknown default:
            completion(.failure(BridgeError.unavailable("蓝牙状态未知")))
        }
    }

    private func readyPeripheral(deviceId: String) throws -> CBPeripheral {
        guard let item = peripheral, item.identifier.uuidString == deviceId else {
            throw BridgeError.notConnected("该设备尚未连接")
        }
        guard item.state == .connected else {
            throw BridgeError.notConnected("蓝牙连接已断开")
        }
        guard ready else {
            throw BridgeError.notConnected("服务发现尚未完成")
        }
        return item
    }

    private func findCharacteristic(
        _ item: CBPeripheral, serviceId: String, characteristicId: String
    ) throws -> CBCharacteristic {
        guard let wantedService = Self.canonicalUUID(serviceId),
              let wantedCharacteristic = Self.canonicalUUID(characteristicId) else {
            throw BridgeError.invalidRequest("蓝牙 UUID 无效")
        }
        guard let service = (item.services ?? []).first(where: {
            Self.canonicalUUID($0.uuid.uuidString) == wantedService
        }) else {
            throw BridgeError.notFound("设备上没有该服务")
        }
        guard let characteristic = (service.characteristics ?? []).first(where: {
            Self.canonicalUUID($0.uuid.uuidString) == wantedCharacteristic
        }) else {
            throw BridgeError.notFound("设备上没有该特征")
        }
        return characteristic
    }

    private func startConnectionTimeout(for item: CBPeripheral) {
        connectionTimeout?.cancel()
        let identifier = item.identifier
        let timeout = DispatchWorkItem { [weak self] in
            guard let self = self, let active = self.peripheral,
                  active.identifier == identifier, active.state != .connected else { return }
            self.central.cancelPeripheralConnection(active)
            self.failPendingOperations(BridgeError.timeout("连接保护板超时"))
            self.emitDisconnected(id: identifier.uuidString, message: "连接保护板超时")
        }
        connectionTimeout = timeout
        queue.asyncAfter(deadline: .now() + 20, execute: timeout)
    }

    private func startDiscovery(on item: CBPeripheral) {
        connectionTimeout?.cancel()
        connectionTimeout = nil
        discoveryTimeout?.cancel()
        ready = false
        discovering = true
        pendingServices.removeAll()
        let timeout = DispatchWorkItem { [weak self] in
            guard let self = self, self.discovering else { return }
            self.discovering = false
            self.pendingServices.removeAll()
            self.failPendingOperations(BridgeError.timeout("服务发现超时"))
            self.central.cancelPeripheralConnection(item)
            self.emitDisconnected(id: item.identifier.uuidString, message: "服务发现超时")
        }
        discoveryTimeout = timeout
        queue.asyncAfter(deadline: .now() + 20, execute: timeout)
        item.discoverServices(nil)
    }

    private func finishDiscovery() {
        guard discovering else { return }
        discovering = false
        ready = true
        discoveryTimeout?.cancel()
        discoveryTimeout = nil
        if let id = peripheral?.identifier.uuidString {
            emit("connected", ["id": id])
        }
    }

    private func processWrites() {
        guard activeWrite == nil, !writeQueue.isEmpty,
              let item = peripheral, item.state == .connected, ready else { return }
        let operation = writeQueue.removeFirst()
        activeWrite = operation
        let timeout = DispatchWorkItem { [weak self] in
            self?.finishWrite(id: operation.id, result: .failure(BridgeError.timeout("写入特征超时")))
        }
        writeTimeout = timeout
        queue.asyncAfter(deadline: .now() + 15, execute: timeout)

        if operation.type == .withResponse {
            item.writeValue(operation.data, for: operation.characteristic, type: .withResponse)
        } else if item.canSendWriteWithoutResponse {
            item.writeValue(operation.data, for: operation.characteristic, type: .withoutResponse)
            finishWrite(id: operation.id, result: .success(NSNull()))
        }
    }

    private func finishWrite(id: UUID, result: Result<Any, Error>) {
        guard let operation = activeWrite, operation.id == id else { return }
        activeWrite = nil
        writeTimeout?.cancel()
        writeTimeout = nil
        operation.completion(result)
        queue.async { self.processWrites() }
    }

    private func failPendingOperations(_ error: Error) {
        connectionTimeout?.cancel()
        connectionTimeout = nil
        discoveryTimeout?.cancel()
        discoveryTimeout = nil
        discovering = false
        ready = false
        pendingServices.removeAll()

        let pendingReads = reads
        reads.removeAll()
        pendingReads.forEach {
            $0.value.timeout.cancel()
            $0.value.completion(.failure(error))
        }
        let pendingNotifications = notifications
        notifications.removeAll()
        pendingNotifications.forEach {
            $0.value.timeout.cancel()
            $0.value.completion(.failure(error))
        }

        let pendingWrites = writeQueue
        writeQueue.removeAll()
        pendingWrites.forEach { $0.completion(.failure(error)) }
        if let operation = activeWrite {
            activeWrite = nil
            writeTimeout?.cancel()
            writeTimeout = nil
            operation.completion(.failure(error))
        }
    }

    private func remember(_ item: CBPeripheral) {
        let id = item.identifier.uuidString
        savedIDs.insert(id)
        savedNames[id] = item.name ?? savedNames[id] ?? id
        defaults.set(savedIDs.sorted(), forKey: savedIDsKey)
        defaults.set(savedNames, forKey: namesKey)
    }

    private func emit(_ name: String, _ value: [String: Any]) {
        eventHandler?(name, value)
    }

    private func emitDisconnected(id: String, message: String) {
        emit("disconnected", ["id": id, "message": message])
    }

    static func canonicalUUID(_ value: String) -> String? {
        var uuid = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if uuid.hasPrefix("0x"), uuid.count == 6 { uuid = String(uuid.dropFirst(2)) }
        if uuid.range(of: "^[0-9a-f]{4}$", options: .regularExpression) != nil {
            uuid = "0000" + uuid + "-0000-1000-8000-00805f9b34fb"
        } else if uuid.range(of: "^[0-9a-f]{8}$", options: .regularExpression) != nil {
            uuid += "-0000-1000-8000-00805f9b34fb"
        } else if uuid.range(of: "^[0-9a-f]{32}$", options: .regularExpression) != nil {
            let start = uuid.startIndex
            func part(_ from: Int, _ to: Int) -> String {
                String(uuid[uuid.index(start, offsetBy: from)..<uuid.index(start, offsetBy: to)])
            }
            uuid = [part(0, 8), part(8, 12), part(12, 16), part(16, 20), part(20, 32)].joined(separator: "-")
        }
        let pattern = "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
        return uuid.range(of: pattern, options: .regularExpression) == nil ? nil : uuid
    }
}

extension BLEManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        let waiters = powerWaiters
        powerWaiters.removeAll()
        switch central.state {
        case .poweredOn:
            waiters.forEach { $0(.success(())) }
        case .unknown, .resetting:
            powerWaiters = waiters
        case .poweredOff:
            waiters.forEach { $0(.failure(BridgeError.unavailable("手机蓝牙已关闭"))) }
            failPendingOperations(BridgeError.notConnected("手机蓝牙已关闭"))
            emit("error", ["message": "手机蓝牙已关闭"])
        case .unauthorized:
            waiters.forEach { $0(.failure(BridgeError.unauthorized("请在系统设置中允许使用蓝牙"))) }
            failPendingOperations(BridgeError.unauthorized("蓝牙权限未开启"))
            emit("error", ["message": "蓝牙权限未开启"])
        case .unsupported:
            waiters.forEach { $0(.failure(BridgeError.unavailable("此设备不支持低功耗蓝牙"))) }
        @unknown default:
            waiters.forEach { $0(.failure(BridgeError.unavailable("蓝牙状态未知"))) }
        }
    }

    func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        discovered[peripheral.identifier] = peripheral
        let advertisedName = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let name = advertisedName ?? peripheral.name ?? "未知设备"
        let upper = name.uppercased()
        let likely = upper.hasPrefix("ANT@") || upper.contains("ANTBMS") ||
            upper.contains("ANT-BMS") || upper.contains("ANT BMS")
        emit("scanResult", [
            "id": peripheral.identifier.uuidString,
            "name": name,
            "rssi": RSSI,
            "likely": likely
        ])
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        scanTimeout?.cancel()
        scanTimeout = nil
        central.stopScan()
        startDiscovery(on: peripheral)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        failPendingOperations(error ?? BridgeError.failed("连接保护板失败"))
        emitDisconnected(id: peripheral.identifier.uuidString, message: error?.localizedDescription ?? "连接保护板失败")
    }

    func centralManager(
        _ central: CBCentralManager,
        didDisconnectPeripheral peripheral: CBPeripheral,
        error: Error?
    ) {
        failPendingOperations(error ?? BridgeError.notConnected("连接已断开"))
        emitDisconnected(id: peripheral.identifier.uuidString, message: error?.localizedDescription ?? "连接已断开")
    }
}

extension BLEManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            failPendingOperations(error)
            central.cancelPeripheralConnection(peripheral)
            emitDisconnected(id: peripheral.identifier.uuidString, message: error.localizedDescription)
            return
        }
        let services = peripheral.services ?? []
        pendingServices = Set(services.map(ObjectIdentifier.init))
        if services.isEmpty {
            finishDiscovery()
        } else {
            services.forEach { peripheral.discoverCharacteristics(nil, for: $0) }
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            failPendingOperations(error)
            central.cancelPeripheralConnection(peripheral)
            emitDisconnected(id: peripheral.identifier.uuidString, message: error.localizedDescription)
            return
        }
        pendingServices.remove(ObjectIdentifier(service))
        if pendingServices.isEmpty { finishDiscovery() }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        let key = ObjectIdentifier(characteristic)
        if let error = error {
            if let operation = reads.removeValue(forKey: key) {
                operation.timeout.cancel()
                operation.completion(.failure(error))
            }
            emit("error", ["message": error.localizedDescription])
            return
        }
        let data = characteristic.value ?? Data()
        if let operation = reads.removeValue(forKey: key) {
            operation.timeout.cancel()
            operation.completion(.success(data.base64EncodedString()))
        }
        if characteristic.isNotifying {
            emit("notification", [
                "deviceId": peripheral.identifier.uuidString,
                "serviceUuid": Self.canonicalUUID(characteristic.service?.uuid.uuidString ?? "") ?? "",
                "characteristicUuid": Self.canonicalUUID(characteristic.uuid.uuidString) ?? "",
                "data": data.base64EncodedString()
            ])
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let operation = activeWrite, operation.characteristic == characteristic else { return }
        if let error = error {
            finishWrite(id: operation.id, result: .failure(error))
        } else {
            finishWrite(id: operation.id, result: .success(NSNull()))
        }
    }

    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        guard let operation = activeWrite, operation.type == .withoutResponse else {
            processWrites()
            return
        }
        peripheral.writeValue(operation.data, for: operation.characteristic, type: .withoutResponse)
        finishWrite(id: operation.id, result: .success(NSNull()))
    }

    func peripheral(
        _ peripheral: CBPeripheral,
        didUpdateNotificationStateFor characteristic: CBCharacteristic,
        error: Error?
    ) {
        let key = ObjectIdentifier(characteristic)
        guard let operation = notifications.removeValue(forKey: key) else { return }
        operation.timeout.cancel()
        if let error = error { operation.completion(.failure(error)) }
        else { operation.completion(.success(NSNull())) }
    }
}

private extension Result {
    var error: Failure? {
        if case .failure(let error) = self { return error }
        return nil
    }
}
