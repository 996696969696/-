import Foundation
import WebKit

enum BridgeError: LocalizedError {
    case invalidRequest(String)
    case notFound(String)
    case notConnected(String)
    case unavailable(String)
    case unauthorized(String)
    case timeout(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .invalidRequest(let message), .notFound(let message), .notConnected(let message),
             .unavailable(let message), .unauthorized(let message), .timeout(let message), .failed(let message):
            return message
        }
    }

    var javaScriptName: String {
        switch self {
        case .invalidRequest: return "InvalidStateError"
        case .notFound: return "NotFoundError"
        case .unauthorized: return "SecurityError"
        case .notConnected, .unavailable, .timeout, .failed: return "NetworkError"
        }
    }
}

final class NativeBridge: NSObject, WKScriptMessageHandler {
    private weak var webView: WKWebView?
    private let ble = BLEManager()
    private let notifications = NotificationManager()

    override init() {
        super.init()
        ble.eventHandler = { [weak self] name, value in
            self?.send(["type": "event", "name": name, "value": value])
        }
    }

    func attach(to webView: WKWebView) {
        self.webView = webView
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "bms", message.frameInfo.isMainFrame, isTrusted(message.frameInfo.securityOrigin) else {
            return
        }
        guard let body = message.body as? [String: Any],
              let id = body["id"] as? String,
              let method = body["method"] as? String else {
            return
        }
        let params = body["params"] as? [String: Any] ?? [:]
        handle(method: method, params: params, id: id)
    }

    private func isTrusted(_ origin: WKSecurityOrigin) -> Bool {
        if origin.protocol == "file" { return true }
        return origin.protocol == "https" && origin.host.lowercased() == "sbljhl.cc.cd"
    }

    private func handle(method: String, params: [String: Any], id: String) {
        let completion: (Result<Any, Error>) -> Void = { [weak self] result in
            self?.respond(id: id, result: result)
        }

        switch method {
        case "scanStart":
            ble.scanStart(completion: completion)
        case "scanStop":
            ble.scanStop(completion: completion)
        case "getDevices":
            ble.getDevices(completion: completion)
        case "connect":
            withDeviceID(params, id: id) { ble.connect(deviceId: $0, completion: completion) }
        case "disconnect":
            ble.disconnect(deviceId: params["deviceId"] as? String, completion: completion)
        case "getServices":
            withDeviceID(params, id: id) { ble.getServices(deviceId: $0, completion: completion) }
        case "getCharacteristics":
            withDeviceAndService(params, id: id) { deviceId, serviceId in
                ble.getCharacteristics(deviceId: deviceId, serviceId: serviceId, completion: completion)
            }
        case "read":
            withCharacteristic(params, id: id) { deviceId, serviceId, characteristicId in
                ble.read(deviceId: deviceId, serviceId: serviceId, characteristicId: characteristicId, completion: completion)
            }
        case "write":
            withCharacteristic(params, id: id) { deviceId, serviceId, characteristicId in
                guard let base64 = params["data"] as? String, let data = Data(base64Encoded: base64) else {
                    completion(.failure(BridgeError.invalidRequest("无效的写入数据")))
                    return
                }
                let withResponse = params["withResponse"] as? Bool ?? true
                ble.write(deviceId: deviceId, serviceId: serviceId, characteristicId: characteristicId,
                          data: data, withResponse: withResponse, completion: completion)
            }
        case "setNotify":
            withCharacteristic(params, id: id) { deviceId, serviceId, characteristicId in
                let enabled = params["enabled"] as? Bool ?? true
                ble.setNotify(deviceId: deviceId, serviceId: serviceId, characteristicId: characteristicId,
                              enabled: enabled, completion: completion)
            }
        case "notifStatus":
            notifications.status(completion: completion)
        case "notifRequest":
            notifications.request(completion: completion)
        case "notify":
            let title = params["title"] as? String ?? "远程保护板"
            let body = params["body"] as? String ?? ""
            notifications.notify(title: title, body: body, completion: completion)
        default:
            completion(.failure(BridgeError.invalidRequest("未知原生方法: \(method)")))
        }
    }

    private func withDeviceID(_ params: [String: Any], id: String, operation: (String) -> Void) {
        guard let deviceId = params["deviceId"] as? String, !deviceId.isEmpty else {
            respond(id: id, result: .failure(BridgeError.invalidRequest("缺少设备标识")))
            return
        }
        operation(deviceId)
    }

    private func withDeviceAndService(
        _ params: [String: Any], id: String, operation: (String, String) -> Void
    ) {
        withDeviceID(params, id: id) { deviceId in
            guard let serviceId = params["serviceUuid"] as? String, !serviceId.isEmpty else {
                self.respond(id: id, result: .failure(BridgeError.invalidRequest("缺少服务 UUID")))
                return
            }
            operation(deviceId, serviceId)
        }
    }

    private func withCharacteristic(
        _ params: [String: Any], id: String, operation: (String, String, String) -> Void
    ) {
        withDeviceAndService(params, id: id) { deviceId, serviceId in
            guard let characteristicId = params["characteristicUuid"] as? String, !characteristicId.isEmpty else {
                self.respond(id: id, result: .failure(BridgeError.invalidRequest("缺少特征 UUID")))
                return
            }
            operation(deviceId, serviceId, characteristicId)
        }
    }

    private func respond(id: String, result: Result<Any, Error>) {
        switch result {
        case .success(let value):
            send(["type": "response", "id": id, "ok": true, "value": value])
        case .failure(let error):
            let bridgeError = error as? BridgeError
            send([
                "type": "response", "id": id, "ok": false,
                "error": [
                    "name": bridgeError?.javaScriptName ?? "NetworkError",
                    "message": error.localizedDescription
                ]
            ])
        }
    }

    private func send(_ payload: [String: Any]) {
        let deliver = { [weak self] in
            guard let self = self, let webView = self.webView,
                  JSONSerialization.isValidJSONObject(payload),
                  let data = try? JSONSerialization.data(withJSONObject: payload),
                  let json = String(data: data, encoding: .utf8) else { return }
            webView.evaluateJavaScript("window.__bmsNativeCallback && window.__bmsNativeCallback(\(json));")
        }
        if Thread.isMainThread { deliver() }
        else { DispatchQueue.main.async(execute: deliver) }
    }
}
