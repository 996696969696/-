import Foundation
import UserNotifications

final class NotificationManager: NSObject, UNUserNotificationCenterDelegate {
    private let center = UNUserNotificationCenter.current()

    override init() {
        super.init()
        center.delegate = self
    }

    func status(completion: @escaping (Result<Any, Error>) -> Void) {
        center.getNotificationSettings { settings in
            completion(.success(Self.permissionString(settings.authorizationStatus)))
        }
    }

    func request(completion: @escaping (Result<Any, Error>) -> Void) {
        center.requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(granted ? "granted" : "denied"))
            }
        }
    }

    func notify(title: String, body: String, completion: @escaping (Result<Any, Error>) -> Void) {
        status { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .failure(let error):
                completion(.failure(error))
            case .success(let value):
                guard let permission = value as? String, permission == "granted" else {
                    completion(.failure(BridgeError.unauthorized("通知权限未开启")))
                    return
                }
                let content = UNMutableNotificationContent()
                content.title = title
                content.body = body
                content.sound = .default
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
                self.center.add(request) { error in
                    if let error = error { completion(.failure(error)) }
                    else { completion(.success(NSNull())) }
                }
            }
        }
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound])
    }

    private static func permissionString(_ status: UNAuthorizationStatus) -> String {
        switch status {
        case .authorized, .provisional, .ephemeral:
            return "granted"
        case .denied:
            return "denied"
        case .notDetermined:
            return "default"
        @unknown default:
            return "default"
        }
    }
}
