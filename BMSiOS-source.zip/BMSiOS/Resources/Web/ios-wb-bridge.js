(function () {
  if (window.__wbShim || !window.BMSRPC) return;
  window.__wbShim = true;

  var RPC = window.BMSRPC;
  var deviceById = Object.create(null);
  var charByKey = Object.create(null);
  var pendingRequest = null;
  var currentDevice = null;

  try {
    if (!window.isSecureContext) Object.defineProperty(window, 'isSecureContext', { value: true, configurable: true });
  } catch (e) {}

  function namedError(name, message) {
    var error = new Error(message);
    error.name = name;
    return error;
  }

  function canonicalUUID(value) {
    var uuid = String(value || '').trim().toLowerCase();
    if (/^0x[0-9a-f]{4}$/.test(uuid)) uuid = uuid.slice(2);
    if (/^[0-9a-f]{4}$/.test(uuid)) uuid = '0000' + uuid + '-0000-1000-8000-00805f9b34fb';
    else if (/^[0-9a-f]{8}$/.test(uuid)) uuid = uuid + '-0000-1000-8000-00805f9b34fb';
    else if (/^[0-9a-f]{32}$/.test(uuid)) {
      uuid = uuid.slice(0, 8) + '-' + uuid.slice(8, 12) + '-' + uuid.slice(12, 16) + '-' +
        uuid.slice(16, 20) + '-' + uuid.slice(20);
    }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(uuid)) {
      throw namedError('TypeError', '无效蓝牙 UUID: ' + value);
    }
    return uuid;
  }

  function b64encode(bytes) {
    var binary = '';
    for (var i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i] & 255);
    return btoa(binary);
  }

  function b64decode(value) {
    var binary = atob(String(value || ''));
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i) & 255;
    return bytes;
  }

  function asBytes(value) {
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (value && value.buffer) return new Uint8Array(value.buffer, value.byteOffset || 0, value.byteLength);
    return Uint8Array.from(value || []);
  }

  function addListener(target, type, callback) {
    target.__listeners = target.__listeners || Object.create(null);
    var listeners = target.__listeners[type] || (target.__listeners[type] = []);
    if (listeners.indexOf(callback) < 0) listeners.push(callback);
  }

  function removeListener(target, type, callback) {
    var listeners = target.__listeners && target.__listeners[type];
    if (!listeners) return;
    target.__listeners[type] = listeners.filter(function (item) { return item !== callback; });
  }

  function dispatch(target, type, event) {
    var listeners = target.__listeners && target.__listeners[type];
    if (!listeners) return;
    listeners.slice().forEach(function (callback) {
      try { callback(event); } catch (e) {}
    });
  }

  function characteristicKey(deviceId, serviceUuid, characteristicUuid) {
    return deviceId + '/' + canonicalUUID(serviceUuid) + '/' + canonicalUUID(characteristicUuid);
  }

  function normalizedProperties(value) {
    value = value || {};
    return {
      read: !!value.read,
      write: !!value.write,
      writeWithoutResponse: !!value.writeWithoutResponse,
      notify: !!value.notify,
      indicate: !!value.indicate,
      broadcast: !!value.broadcast,
      authenticatedSignedWrites: !!value.authenticatedSignedWrites,
      reliableWrite: !!value.reliableWrite,
      writableAuxiliaries: !!value.writableAuxiliaries
    };
  }

  function makeCharacteristic(device, service, descriptor) {
    var uuid = canonicalUUID(descriptor.uuid);
    var key = characteristicKey(device.id, service.uuid, uuid);
    var existing = charByKey[key];
    if (existing) {
      existing.properties = normalizedProperties(descriptor);
      return existing;
    }

    var characteristic = {
      uuid: uuid,
      service: service,
      value: null,
      properties: normalizedProperties(descriptor),
      __listeners: Object.create(null),
      addEventListener: function (type, callback) { addListener(characteristic, type, callback); },
      removeEventListener: function (type, callback) { removeListener(characteristic, type, callback); },
      readValue: function () {
        return RPC.call('read', {
          deviceId: device.id,
          serviceUuid: service.uuid,
          characteristicUuid: uuid
        }).then(function (value) {
          var bytes = b64decode(value);
          characteristic.value = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
          return characteristic.value;
        });
      },
      writeValue: function (value) {
        return write(value, !!characteristic.properties.write);
      },
      writeValueWithResponse: function (value) { return write(value, true); },
      writeValueWithoutResponse: function (value) { return write(value, false); },
      startNotifications: function () { return setNotify(true); },
      stopNotifications: function () { return setNotify(false); }
    };

    function write(value, withResponse) {
      return RPC.call('write', {
        deviceId: device.id,
        serviceUuid: service.uuid,
        characteristicUuid: uuid,
        data: b64encode(asBytes(value)),
        withResponse: !!withResponse
      }).then(function () {});
    }

    function setNotify(enabled) {
      return RPC.call('setNotify', {
        deviceId: device.id,
        serviceUuid: service.uuid,
        characteristicUuid: uuid,
        enabled: enabled
      }).then(function () { return characteristic; });
    }

    charByKey[key] = characteristic;
    return characteristic;
  }

  function makeService(device, uuid) {
    uuid = canonicalUUID(uuid);
    var service = {
      uuid: uuid,
      getCharacteristic: function (characteristicUuid) {
        return service.getCharacteristics(characteristicUuid).then(function (items) { return items[0]; });
      },
      getCharacteristics: function (characteristicUuid) {
        var wanted = characteristicUuid ? canonicalUUID(characteristicUuid) : '';
        return RPC.call('getCharacteristics', { deviceId: device.id, serviceUuid: uuid }).then(function (items) {
          var descriptors = (items || []).filter(function (item) {
            return !wanted || canonicalUUID(item.uuid) === wanted;
          });
          if (wanted && !descriptors.length) throw namedError('NotFoundError', '设备上没有该特征: ' + wanted);
          return descriptors.map(function (item) { return makeCharacteristic(device, service, item); });
        });
      }
    };
    return service;
  }

  function makeGatt(device) {
    var gatt = {
      connected: false,
      _resolve: null,
      _reject: null,
      connect: function () {
        return new Promise(function (resolve, reject) {
          if (gatt.connected) { resolve(gatt); return; }
          if (gatt._resolve) { reject(namedError('InvalidStateError', '连接正在进行')); return; }
          currentDevice = device;
          gatt._resolve = resolve;
          gatt._reject = reject;
          RPC.call('connect', { deviceId: device.id }).catch(function (error) {
            gatt._resolve = null;
            gatt._reject = null;
            reject(error);
          });
        });
      },
      disconnect: function () {
        return RPC.call('disconnect', { deviceId: device.id }).then(function () {});
      },
      getPrimaryService: function (uuid) {
        return gatt.getPrimaryServices(uuid).then(function (items) { return items[0]; });
      },
      getPrimaryServices: function (uuid) {
        var wanted = uuid ? canonicalUUID(uuid) : '';
        return RPC.call('getServices', { deviceId: device.id }).then(function (items) {
          var uuids = (items || []).map(canonicalUUID).filter(function (item) { return !wanted || item === wanted; });
          if (wanted && !uuids.length) throw namedError('NotFoundError', '设备上没有该服务: ' + wanted);
          return uuids.map(function (item) { return makeService(device, item); });
        });
      }
    };
    return gatt;
  }

  function makeDevice(id, name) {
    id = String(id || '');
    var existing = deviceById[id];
    if (existing) {
      if (name) existing.name = String(name);
      return existing;
    }
    var device = {
      id: id,
      _mac: id,
      name: name ? String(name) : id,
      __listeners: Object.create(null),
      addEventListener: function (type, callback) { addListener(device, type, callback); },
      removeEventListener: function (type, callback) { removeListener(device, type, callback); }
    };
    device.gatt = makeGatt(device);
    deviceById[id] = device;
    return device;
  }

  window.__wbScanResult = function (id, name, rssi, likely) {
    if (typeof window.__bleInlineScanHit === 'function') {
      window.__bleInlineScanHit(String(id || ''), String(name || ''), Number(rssi) || 0, !!likely);
    }
  };

  window.__wbPicked = function (id, name) {
    var device = makeDevice(id, name);
    currentDevice = device;
    var request = pendingRequest;
    pendingRequest = null;
    if (request) request.resolve(device);
  };

  window.__wbCancelReq = function () {
    var request = pendingRequest;
    pendingRequest = null;
    if (request) request.reject(namedError('NotFoundError', 'cancel'));
  };

  window.__wbConnected = function (id) {
    var device = deviceById[String(id || '')] || currentDevice;
    if (!device) return;
    device.gatt.connected = true;
    var resolve = device.gatt._resolve;
    device.gatt._resolve = null;
    device.gatt._reject = null;
    if (resolve) resolve(device.gatt);
  };

  window.__wbDisconnected = function (id, message) {
    var device = deviceById[String(id || '')] || currentDevice;
    if (!device) return;
    device.gatt.connected = false;
    var reject = device.gatt._reject;
    device.gatt._resolve = null;
    device.gatt._reject = null;
    if (reject) reject(namedError('NetworkError', message || '连接已断开'));
    dispatch(device, 'gattserverdisconnected', { target: device });
    if (currentDevice === device) currentDevice = null;
  };

  window.__wbNotify = function (deviceId, serviceUuid, characteristicUuid, value) {
    var key;
    try { key = characteristicKey(deviceId, serviceUuid, characteristicUuid); } catch (e) { return; }
    var characteristic = charByKey[key];
    if (!characteristic) return;
    var bytes = b64decode(value);
    characteristic.value = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    dispatch(characteristic, 'characteristicvaluechanged', { target: characteristic });
  };

  window.__wbError = function (message) {
    if (currentDevice && currentDevice.gatt._reject) {
      var reject = currentDevice.gatt._reject;
      currentDevice.gatt._resolve = null;
      currentDevice.gatt._reject = null;
      reject(namedError('NetworkError', String(message || '蓝牙连接失败')));
    }
    try { if (window.bleLog) window.bleLog('native: ' + (message || ''), 'er'); } catch (e) {}
  };

  window.__bmsNativeEvent = function (message) {
    var value = message.value || {};
    switch (message.name) {
      case 'scanResult':
        window.__wbScanResult(value.id, value.name, value.rssi, value.likely);
        break;
      case 'connected': window.__wbConnected(value.id); break;
      case 'disconnected': window.__wbDisconnected(value.id, value.message); break;
      case 'notification':
        window.__wbNotify(value.deviceId, value.serviceUuid, value.characteristicUuid, value.data);
        break;
      case 'error': window.__wbError(value.message); break;
    }
  };

  function fire(method, params) {
    return RPC.call(method, params || {}).catch(function (error) {
      window.__wbError(error.message);
      return false;
    });
  }

  window.BMSApp = {
    wbScan: function () { return fire('scanStart'); },
    wbScanStop: function () { return fire('scanStop'); },
    wbConnect: function (id) { return fire('connect', { deviceId: id }); },
    wbDisconnect: function () { return fire('disconnect', { deviceId: currentDevice && currentDevice.id }); },
    notify: function (title, body) { return fire('notify', { title: title, body: body }); },
    requestNotifPermission: function () {
      return RPC.call('notifRequest', {}, 60000).then(function (permission) {
        NativeNotification.permission = permission;
        if (typeof window.__notifPermResult === 'function') window.__notifPermResult(permission);
        return permission;
      }).catch(function () { return NativeNotification.permission; });
    }
  };

  var bluetooth = {
    requestDevice: function (options) {
      return new Promise(function (resolve, reject) {
        if (pendingRequest) { reject(namedError('InvalidStateError', '已有设备选择请求')); return; }
        pendingRequest = { resolve: resolve, reject: reject };
        var handled = false;
        try {
          if (typeof window.__wbOpenCard === 'function') handled = window.__wbOpenCard(options || {}) === true;
        } catch (e) {
          pendingRequest = null;
          reject(e);
          return;
        }
        if (!handled) {
          pendingRequest = null;
          reject(namedError('NotFoundError', '连接卡片未就绪'));
        }
      });
    },
    getDevices: function () {
      return RPC.call('getDevices').then(function (items) {
        return (items || []).map(function (item) { return makeDevice(item.id, item.name); });
      });
    },
    getAvailability: function () { return Promise.resolve(true); }
  };

  try { navigator.bluetooth = bluetooth; }
  catch (e) { Object.defineProperty(navigator, 'bluetooth', { value: bluetooth, configurable: true }); }

  function NativeNotification(title, options) {
    options = options || {};
    this.title = String(title || '');
    this.body = String(options.body || '');
    window.BMSApp.notify(this.title, this.body);
  }
  NativeNotification.permission = 'default';
  NativeNotification.requestPermission = function (callback) {
    return window.BMSApp.requestNotifPermission().then(function (permission) {
      if (typeof callback === 'function') callback(permission);
      return permission;
    });
  };
  NativeNotification.prototype.close = function () {};
  NativeNotification.prototype.addEventListener = function () {};
  window.Notification = NativeNotification;
  RPC.call('notifStatus').then(function (permission) { NativeNotification.permission = permission; }).catch(function () {});
})();
