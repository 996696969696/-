/**
 * 保护板连接卡片（远程版专用，随 APK 注入）
 * ---------------------------------------------------------------
 * 直连版（1.0.26）的连接卡片是页面自带的内联面板：直接扫描、按品牌过滤、
 * 点设备即连，全程不弹系统选择框。远程站点的连接页仍是「系统框选设备」的老形式，
 * 这里把那套卡片原样搬到远程页上，用同样的品牌片、设备行、扫描日志与按钮。
 *
 * 触发方式：Web Bluetooth 桥 requestDevice() 之前调用 window.__wbOpenCard()，
 * 卡片出现并调用原生开始扫描；扫描结果由原生经 __wbScanResult -> __bleInlineScanHit 推进来。
 * 用户点「连接」时用 __wbPicked 回填设备，页面的 await requestDevice() 正常 resolve。
 *
 * 内置兜底页（assets/bms.html）本身就有这块面板，检测到 #bleGateMask 时直接让位。
 */
(function () {
  if (window.__wbConnCardReady) return;
  window.__wbConnCardReady = true;

  var KEY_BRAND = 'bms_conn_brand';
  var KEY_RECENT = 'bms_conn_recent';

  var BRANDS = [
    { id: 'ant', name: '蚂蚁板', tag: '', re: /ANT@|ANTBMS|ANT-?BMS|蚂蚁/i },
    { id: 'jk', name: '极空板', tag: '', re: /^JK[-_ 0-9]|JK-B|极空/i },
    { id: 'jbd', name: '嘉佰达', tag: '', re: /JBD|嘉佰达|嘉百达|JIABAIDA/i },
    { id: 'spider', name: '小蜘蛛·小象', tag: '', re: /XIAOXIANG|小蜘蛛|小象|APP_ALL|SMART.?BMS|TANK|SP\d\dS|OVERKILL/i },
    { id: 'daly', name: 'Daly 达立', tag: '', re: /^DL-|DALY|达立/i },
    { id: 'yanyang', name: '彦阳板', tag: '待核实', re: /YY[-_ ]|彦阳/i },
    { id: 'baolian', name: '保锂安', tag: '待核实', re: /保锂安|^BLA[-_ ]/i },
    { id: 'byd', name: '比亚迪', tag: '待核实', re: /BYD|比亚迪/i },
    { id: 'xingheng', name: '星恒', tag: '待核实', re: /星恒|^STAR[-_ ]|^SH[-_ ]/i },
    { id: 'huajiyuan', name: '华集源', tag: '待核实', re: /华集源|^HJY[-_ ]/i },
    { id: 'tianneng', name: '天能锂电', tag: '待核实', re: /天能|^TN[-_ ]/i },
    { id: 'chaowei', name: '超威锂电', tag: '常见', re: /超威|^CW[-_ ]/i },
    { id: 'auto', name: '自动识别', tag: '', re: null }
  ];

  var CSS = [
    '#wbCard{position:fixed;inset:0;z-index:2147483000;display:none;align-items:flex-end;justify-content:center;',
    'background:rgba(16,21,32,.28);-webkit-backdrop-filter:blur(10px) saturate(1.2);backdrop-filter:blur(10px) saturate(1.2);',
    'font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#15161a;}',
    'html.wb-card-open,html.wb-card-open body{overflow:hidden!important}',
    '#wbCard *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}',
    '#wbCard .cc-dlg{width:100%;max-width:540px;max-height:92vh;overflow:auto;-webkit-overflow-scrolling:touch;',
    'padding:12px 14px calc(16px + env(safe-area-inset-bottom,0px));border-radius:22px 22px 0 0;',
    'background:linear-gradient(180deg,#ffffff 0%,#f7f9fc 100%);box-shadow:0 -20px 60px -30px rgba(15,22,38,.55);',
    'border-top:1px solid rgba(255,255,255,.9);animation:ccIn .26s cubic-bezier(.22,.9,.28,1);}',
    '@keyframes ccIn{from{transform:translateY(20px);opacity:.55}to{transform:none;opacity:1}}',
    '#wbCard .cc-hd{display:flex;align-items:center;gap:10px;margin:0 0 10px}',
    '#wbCard .cc-hd-ic{flex:0 0 34px;width:34px;height:34px;border-radius:11px;display:grid;place-items:center;',
    'color:#4f46e5;background:rgba(79,70,229,.09)}',
    '#wbCard .cc-tt{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}',
    '#wbCard .cc-tt b{font-size:14.5px;font-weight:800;line-height:1.2}',
    '#wbCard .cc-tt span{font-size:10.5px;color:#6c737f}',
    '#wbCard .cc-x{flex:0 0 30px;width:30px;height:30px;border:0;border-radius:50%;display:grid;place-items:center;',
    'color:#565d69;background:rgba(17,23,38,.05);font-size:13px;line-height:1;padding:0}',
    '#wbCard .cc-st{font-size:11.5px;font-weight:700;color:#2b2f37;padding:7px 10px;border-radius:9px;',
    'background:rgba(17,23,38,.04);margin-bottom:8px;line-height:1.45}',
    '#wbCard .cc-list{display:flex;flex-direction:column;gap:7px;margin:0 0 4px}',
    '#wbCard .cc-dev{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:11px;',
    'background:rgba(255,255,255,.94);border:1px solid rgba(17,23,38,.07);cursor:pointer;',
    'box-shadow:0 1px 0 rgba(255,255,255,.9) inset}',
    '#wbCard .cc-dev:active{transform:scale(.99)}',
    '#wbCard .cc-dev .sd-ic{flex:0 0 30px;width:30px;height:30px;border-radius:9px;display:grid;place-items:center;',
    'color:#fff;background:#1c2230}',
    '#wbCard .cc-dev .sd-mid{flex:1;min-width:0}',
    '#wbCard .cc-dev .sd-nm{font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '#wbCard .cc-dev .sd-mac{font-size:9.5px;color:#6c737f;font-variant-numeric:tabular-nums;margin-top:1px}',
    '#wbCard .cc-dev .sd-go{flex:0 0 auto;font-size:10.5px;font-weight:800;color:#4f46e5}',
    '#wbCard .cc-dev.rec{background:rgba(79,70,229,.05);border-color:rgba(79,70,229,.16)}',
    '#wbCard .cc-dev.rec .sd-nm{color:#4338ca}',
    '#wbCard .cc-sec{font-size:10.5px;font-weight:700;color:#6c737f;margin:2px 0 0}',
    '#wbCard .cc-row{display:flex;gap:7px;margin-top:8px}',
    '#wbCard .cc-btn{flex:1;min-height:42px;padding:0 12px;border:0;border-radius:12px;',
    'font-size:12px;font-weight:800;background:#15161a;color:#fff;transition:background .16s}',
    '#wbCard .cc-btn:active{transform:scale(.99)}',
    '#wbCard .cc-btn.sec{background:rgba(17,23,38,.05);color:#2b2f37}',
    '#wbCard .cc-btn.warn{background:rgba(180,119,10,.14);color:#9a6404}',
    '#wbCard .cc-brands{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}',
    '#wbCard .cc-chip{padding:6px 11px;border:1px solid rgba(17,23,38,.07);border-radius:999px;',
    'font-size:10.5px;font-weight:700;background:rgba(255,255,255,.7);color:#565d69;line-height:1.2}',
    '#wbCard .cc-chip.on{background:rgba(79,70,229,.10);color:#4f46e5;border-color:rgba(79,70,229,.3)}',
    '#wbCard .cc-chip .q{opacity:.55;font-weight:600;margin-left:3px;font-size:.9em}',
    '#wbCard .cc-log{margin-top:9px;max-height:150px;overflow:auto;padding:9px 11px;border-radius:9px;',
    'background:rgba(17,23,38,.04);font-family:ui-monospace,SFMono-Regular,Menlo,monospace;',
    'font-size:10px;line-height:1.6;color:#565d69}',
    '#wbCard .cc-log:empty{display:none}',
    '#wbCard .cc-log div{white-space:pre-wrap;word-break:break-all}',
    '#wbCard .cc-log .er{color:#c92f28}',
    '#wbCard .cc-log .ok{color:#0a8a5c}'
  ].join('');

  var root = null, listEl = null, stateEl = null, logEl = null, chipsEl = null, recentEl = null;
  var scanning = false, timer = 0, opened = false;

  var brandPref = load(KEY_BRAND) || 'ant';
  var mode = 'all';

  function store(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function load(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function brandById(id) {
    for (var i = 0; i < BRANDS.length; i++) if (BRANDS[i].id === id) return BRANDS[i];
    return null;
  }
  function brandName(id) { var b = brandById(id); return b ? b.name : '自动识别'; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function now() {
    var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; };
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }

  function injectCss() {
    if (document.getElementById('wbCardCss')) return;
    var s = document.createElement('style');
    s.id = 'wbCardCss';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  var BT_ICON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7l10 10-5 4V3l5 4L7 17"/></svg>';

  function build() {
    if (root) return;
    injectCss();
    root = document.createElement('div');
    root.id = 'wbCard';
    root.setAttribute('aria-hidden', 'true');
    root.innerHTML =
      '<div class="cc-dlg" role="dialog" aria-modal="true" aria-label="保护板连接">' +
        '<div class="cc-hd">' +
          '<div class="cc-hd-ic">' + BT_ICON + '</div>' +
          '<div class="cc-tt"><b>保护板连接</b><span>手机蓝牙直连 · 免系统选择框</span></div>' +
          '<button class="cc-x" type="button" id="wbCardX" aria-label="关闭">✕</button>' +
        '</div>' +
        '<div class="cc-st" id="wbCardState"></div>' +
        '<div class="cc-list" id="wbCardRecent"></div>' +
        '<div class="cc-list" id="wbCardList"></div>' +
        '<div class="cc-row"><button class="cc-btn warn" type="button" id="wbCardCancel">取消扫描</button></div>' +
        '<div class="cc-row"><button class="cc-btn sec" type="button" id="wbCardAll">扫描全部设备（其他协议板）</button></div>' +
        '<div class="cc-brands" id="wbCardBrands"></div>' +
        '<div class="cc-log" id="wbCardLog"></div>' +
        '<div class="cc-row"><button class="cc-btn sec" type="button" id="wbCardCopy">复制原始帧（发给作者补协议）</button></div>' +
      '</div>';
    document.body.appendChild(root);

    listEl = root.querySelector('#wbCardList');
    recentEl = root.querySelector('#wbCardRecent');
    stateEl = root.querySelector('#wbCardState');
    logEl = root.querySelector('#wbCardLog');
    chipsEl = root.querySelector('#wbCardBrands');

    root.querySelector('#wbCardX').onclick = cancel;
    root.querySelector('#wbCardCancel').onclick = cancel;
    root.querySelector('#wbCardAll').onclick = function () { rescan('all'); };
    root.querySelector('#wbCardCopy').onclick = copyRaw;
    chipsEl.onclick = function (ev) {
      var b = ev.target.closest ? ev.target.closest('.cc-chip') : null;
      if (!b) return;
      rescan(b.getAttribute('data-brand'));
    };
  }

  function setState(txt) { if (stateEl) stateEl.textContent = txt; }

  function log(txt, cls) {
    if (!logEl) return;
    var line = document.createElement('div');
    if (cls) line.className = cls;
    line.textContent = '[' + now() + '] ' + txt;
    logEl.appendChild(line);
    while (logEl.children.length > 40) logEl.removeChild(logEl.firstChild);
    logEl.scrollTop = logEl.scrollHeight;
  }

  function renderChips() {
    if (!chipsEl) return;
    var html = '';
    for (var i = 0; i < BRANDS.length; i++) {
      var b = BRANDS[i];
      html += '<button class="cc-chip' + (b.id === brandPref ? ' on' : '') + '" type="button" data-brand="' +
        b.id + '">' + esc(b.name) + (b.tag ? '<span class="q">·' + esc(b.tag) + '</span>' : '') + '</button>';
    }
    chipsEl.innerHTML = html;
  }

  function recentRows() {
    try { return JSON.parse(load(KEY_RECENT) || '[]'); } catch (e) { return []; }
  }
  function saveRecent(mac, name) {
    var arr = recentRows().filter(function (r) { return r.mac !== mac; });
    arr.unshift({ mac: mac, name: name });
    store(KEY_RECENT, JSON.stringify(arr.slice(0, 4)));
  }
  function renderRecent() {
    if (!recentEl) return;
    var arr = recentRows();
    recentEl.innerHTML = arr.length
      ? '<div class="cc-sec">最近连接 · 点一下直接连</div>' + arr.map(function (r) {
          return '<div class="cc-dev rec" data-mac="' + esc(r.mac) + '" data-name="' + esc(r.name) + '">' +
            '<div class="sd-ic">' + BT_ICON + '</div>' +
            '<div class="sd-mid"><div class="sd-nm">' + esc(r.name || '未知设备') + '</div>' +
            '<div class="sd-mac">' + esc(r.mac) + '</div></div>' +
            '<div class="sd-go">连接 ›</div></div>';
        }).join('')
      : '';
  }

  function accept(name, likely) {
    if (mode === 'all') return true;
    if (mode === 'ant') return /^ANT@/i.test(name || '') || !!likely;
    var b = brandById(mode);
    if (b && b.re) return b.re.test(name || '');
    return true;
  }

  function addRow(mac, name, recent) {
    if (!listEl) return;
    if (listEl.querySelector('[data-mac="' + mac + '"]')) return;
    var row = document.createElement('div');
    row.className = 'cc-dev';
    row.setAttribute('data-mac', mac);
    row.setAttribute('data-name', name || '');
    row.innerHTML = '<div class="sd-ic">' + BT_ICON + '</div>' +
      '<div class="sd-mid"><div class="sd-nm">' + esc(name || '未知设备') + '</div>' +
      '<div class="sd-mac">' + esc(mac) + '</div></div>' +
      '<div class="sd-go">连接 ›</div>';
    listEl.appendChild(row);
  }

  // 原生扫描结果 -> 卡片
  window.__bleInlineScanHit = function (mac, name, rssi, likely) {
    if (!opened || !scanning || !mac) return;
    if (!accept(name, likely)) return;
    addRow(mac, name);
  };

  function clearRows() {
    if (listEl) listEl.innerHTML = '';
    if (recentEl) recentEl.innerHTML = '';
  }

  function scanStateText() {
    return mode === 'all'
      ? '正在扫描全部蓝牙设备，点设备连接…'
      : '正在扫描「' + brandName(mode) + '」，点设备连接…';
  }

  function startScan() {
    scanning = true;
    setState(scanStateText());
    var btn = root.querySelector('#wbCardCancel');
    if (btn) { btn.textContent = '取消扫描'; btn.className = 'cc-btn warn'; }
    log(mode === 'all'
      ? '正在扫描附近全部蓝牙设备，点设备即可连接…'
      : '正在扫描「' + brandName(mode) + '」，按广播名列出匹配设备，点设备即可连接…');
    try { window.BMSApp.wbScan(); } catch (e) { log('扫描失败：' + (e && e.message), 'er'); }
    clearTimeout(timer);
    timer = setTimeout(function () {
      if (!scanning) return;
      scanning = false;
      setState('扫描已结束，可点下方「扫描全部设备」重新扫描，或点已列出的设备连接。');
      log('本轮扫描结束（20 秒）。', 'in');
    }, 21000);
  }

  function rescan(nextMode) {
    if (nextMode) {
      if (nextMode === 'all') mode = 'all';
      else { mode = nextMode; brandPref = nextMode; store(KEY_BRAND, brandPref); }
    }
    renderChips();
    clearRows();
    if (listEl) listEl.innerHTML = '';
    startScan();
  }

  function selectDevice(mac, name) {
    if (!mac) return;
    scanning = false;
    clearTimeout(timer);
    log('选中「' + (name || mac) + '」，正在连接…', 'ok');
    saveRecent(mac, name || '未知设备');
    try { window.BMSApp.wbScanStop(); } catch (e) {}
    close();
    var resolved = false;
    try {
      if (typeof window.__wbPicked === 'function') { window.__wbPicked(mac, name || mac); resolved = true; }
    } catch (e) {}
    if (!resolved) {
      try { window.BMSApp.wbConnect(mac); } catch (e) {}
    }
  }

  function cancel() {
    if (scanning) { try { window.BMSApp.wbScanStop(); } catch (e) {} }
    scanning = false;
    clearTimeout(timer);
    try { if (typeof window.__wbCancelReq === 'function') window.__wbCancelReq(); } catch (e) {}
    log('已取消扫描。', 'in');
    close();
  }

  function copyRaw() {
    var txt = '';
    try {
      if (typeof window.bleParamText === 'function') txt = window.bleParamText(true) || '';
    } catch (e) {}
    if (!txt) txt = logEl ? logEl.innerText : '';
    if (!txt) { log('暂无可复制的连接信息。', 'er'); return; }
    var done = function (ok) { log(ok ? '连接信息已复制，可直接发给作者。' : '复制失败，请长按选择日志手动复制。', ok ? 'ok' : 'er'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(function () { done(true); }, function () { fallbackCopy(txt, done); });
    } else {
      fallbackCopy(txt, done);
    }
  }
  function fallbackCopy(txt, done) {
    try {
      var ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = document.execCommand('copy');
      document.body.removeChild(ta);
      done(!!ok);
    } catch (e) { done(false); }
  }

  function close() {
    opened = false;
    if (root) { root.style.display = 'none'; root.setAttribute('aria-hidden', 'true'); }
    document.documentElement.classList.remove('wb-card-open');
  }

  function open(options) {
    // iOS 没有系统 Web Bluetooth 选择框，本地页和远程页统一使用此连接卡片。
    if (options && options.acceptAllDevices) mode = 'all';
    else if (options && options.filters) {
      for (var i = 0; i < options.filters.length; i += 1) {
        if (options.filters[i] && options.filters[i].namePrefix === 'ANT@') { mode = 'ant'; break; }
      }
    }
    build();
    injectCss();
    opened = true;
    scanning = false;
    clearTimeout(timer);
    if (logEl) logEl.innerHTML = '';
    clearRows();
    renderChips();
    renderRecent();
    root.style.display = 'flex';
    root.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('wb-card-open');

    // 设备行点击（扫描结果 + 最近连接）
    root.onclick = function (ev) {
      var t = ev.target;
      var row = t.closest ? t.closest('.cc-dev') : null;
      if (row) {
        selectDevice(row.getAttribute('data-mac'), row.getAttribute('data-name'));
        return;
      }
      if (t === root) cancel();
    };
    startScan();
    return true;
  }

  window.__wbOpenCard = open;
})();
