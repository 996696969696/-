(function () {
  if (window.BMSRPC) return;

  var pending = Object.create(null);
  var sequence = 0;

  function makeError(value, fallbackName) {
    var error = new Error((value && value.message) || (typeof value === 'string' ? value : 'Native bridge error'));
    error.name = (value && value.name) || fallbackName || 'NetworkError';
    return error;
  }

  function settle(id, ok, value) {
    var request = pending[id];
    if (!request) return false;
    delete pending[id];
    clearTimeout(request.timer);
    if (ok) request.resolve(value);
    else request.reject(makeError(value));
    return true;
  }

  function receive(message) {
    if (typeof message === 'string') {
      try { message = JSON.parse(message); } catch (e) { return false; }
    }
    if (!message || typeof message !== 'object') return false;

    if (message.type === 'response') {
      return settle(String(message.id || ''), !!message.ok, message.ok ? message.value : message.error);
    }
    if (message.type === 'event') {
      if (typeof window.__bmsNativeEvent !== 'function') return false;
      window.__bmsNativeEvent(message);
      return true;
    }
    return false;
  }

  function call(method, params, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var handler = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.bms;
      if (!handler || typeof handler.postMessage !== 'function') {
        var unavailable = new Error('iOS 原生桥尚未就绪');
        unavailable.name = 'NetworkError';
        reject(unavailable);
        return;
      }

      sequence += 1;
      var id = Date.now().toString(36) + '-' + sequence.toString(36);
      var timer = setTimeout(function () {
        settle(id, false, { name: 'NetworkError', message: method + ' 请求超时' });
      }, timeoutMs || 20000);
      pending[id] = { resolve: resolve, reject: reject, timer: timer };

      try {
        handler.postMessage({ id: id, method: method, params: params || {} });
      } catch (e) {
        settle(id, false, { name: e.name, message: e.message });
      }
    });
  }

  function rejectAll() {
    var ids = Object.keys(pending);
    for (var i = 0; i < ids.length; i += 1) {
      settle(ids[i], false, { name: 'AbortError', message: '页面已关闭' });
    }
  }

  window.__bmsNativeCallback = receive;
  window.BMSRPC = { call: call };
  if (typeof window.addEventListener === 'function') window.addEventListener('pagehide', rejectAll);
})();
